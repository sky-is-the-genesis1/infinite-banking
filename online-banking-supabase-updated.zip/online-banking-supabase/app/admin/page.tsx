'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../../supabaseClient';

export default function Admin() {
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    async function loadUsers() {
      const { data } = await supabase.from('profiles').select('*');
      setUsers(data || []);
    }
    loadUsers();
  }, []);

  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <ul className="mt-4">
        {users.map(u => (
          <li key={u.id} className="border-b py-2">{u.full_name} — {u.role}</li>
        ))}
      </ul>
    </main>
  );
}
