'use client';
import { useState } from 'react';
import { supabase } from '../../../supabaseClient';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const router = useRouter();

  async function handleLogin(e: any) {
    e.preventDefault();
    setMsg('Signing in...');
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) { setMsg(error.message); return; }
      setMsg('Signed in! Redirecting...');
      router.push('/dashboard');
    } catch (err: any) {
      setMsg(err.message || 'Error');
    }
  }

  return (
    <div className="max-w-md mx-auto mt-12 bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-semibold mb-4">Sign in</h2>
      <form onSubmit={handleLogin} className="space-y-3">
        <input className="w-full border p-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} type="email" required />
        <input className="w-full border p-2" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} type="password" required />
        <button className="w-full bg-green-600 text-white py-2 rounded">Sign in</button>
      </form>
      <p className="mt-3 text-sm text-gray-600">{msg}</p>
    </div>
  );
}
