'use client';
import { useState } from 'react';
import { supabase } from '../../../supabaseClient';
import { useRouter } from 'next/navigation';

export default function SignUpPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [msg, setMsg] = useState('');
  const router = useRouter();

  async function handleSignup(e: any) {
    e.preventDefault();
    setMsg('Creating account...');
    try {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) { setMsg(error.message); return; }

      // If user object is present, create profile row
      const userId = data.user?.id;
      if (userId) {
        const { error: pErr } = await supabase.from('profiles').insert({ id: userId, full_name: fullName, role: 'customer' });
        if (pErr) {
          console.error('profile insert error', pErr);
        }
      }

      setMsg('Signup successful — please check your email to confirm (if required). Redirecting to login...');
      setTimeout(() => router.push('/auth/login'), 2000);
    } catch (err: any) {
      setMsg(err.message || 'Error');
    }
  }

  return (
    <div className="max-w-md mx-auto mt-12 bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-semibold mb-4">Create account</h2>
      <form onSubmit={handleSignup} className="space-y-3">
        <input className="w-full border p-2" placeholder="Full name" value={fullName} onChange={e=>setFullName(e.target.value)} required />
        <input className="w-full border p-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} type="email" required />
        <input className="w-full border p-2" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} type="password" required />
        <button className="w-full bg-blue-600 text-white py-2 rounded">Sign up</button>
      </form>
      <p className="mt-3 text-sm text-gray-600">{msg}</p>
    </div>
  );
}
