import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const svc = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

export async function POST(req: Request) {
  const { fromAccountId, toAccountId, amount } = await req.json();
  const { data, error } = await svc.rpc('transfer_atomic', {
    p_from: fromAccountId,
    p_to: toAccountId,
    p_amount: amount
  });
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ success: true, result: data });
}
