'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../../supabaseClient';

export default function Dashboard() {
  const [account, setAccount] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [toAccount, setToAccount] = useState('');
  const [amount, setAmount] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    async function fetchData() {
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;
      if (!user) return;

      const { data: accounts } = await supabase.from('accounts').select('*').eq('user_id', user.id).single();
      setAccount(accounts);

      const { data: txs } = await supabase.from('transactions').select('*').or(`account_from.eq.${accounts.id},account_to.eq.${accounts.id}`).order('created_at', { ascending: false });
      setTransactions(txs || []);
    }
    fetchData();
  }, []);

  async function doTransfer(e: any) {
    e.preventDefault();
    if (!account) { setMsg('No account loaded'); return; }
    setMsg('Processing transfer...');
    try {
      const res = await fetch('/api/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fromAccountId: account.id, toAccountId: toAccount, amount: parseFloat(amount) })
      });
      const data = await res.json();
      if (data.error) setMsg('Error: ' + data.error);
      else {
        setMsg('Transfer successful');
        // refresh transactions & balance
        const { data: updatedAccount } = await supabase.from('accounts').select('*').eq('id', account.id).single();
        setAccount(updatedAccount);
        const { data: txs } = await supabase.from('transactions').select('*').or(`account_from.eq.${account.id},account_to.eq.${account.id}`).order('created_at', { ascending: false });
        setTransactions(txs || []);
      }
    } catch (err: any) {
      setMsg(err.message || 'Error');
    }
  }

  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      {account ? (
        <div className="mt-4">
          <p>Balance: <strong>{account.balance} {account.currency}</strong></p>

          <form onSubmit={doTransfer} className="mt-6 bg-white p-4 rounded shadow max-w-md">
            <h3 className="font-semibold mb-2">Transfer funds</h3>
            <input className="w-full border p-2 mb-2" placeholder="Recipient account id" value={toAccount} onChange={e=>setToAccount(e.target.value)} required />
            <input className="w-full border p-2 mb-2" placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} type="number" step="0.01" required />
            <button className="bg-blue-600 text-white px-4 py-2 rounded">Send</button>
            <p className="mt-2 text-sm">{msg}</p>
          </form>

          <h2 className="mt-6 text-xl font-semibold">Recent Transactions</h2>
          <ul className="mt-2">
            {transactions.map(t => (
              <li key={t.id} className="border-b py-2">{t.type} {t.amount} — {t.status}</li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="mt-4 text-gray-600">Please sign in to view your dashboard.</p>
      )}
    </main>
  );
}
