# Supabase Online Bank — Runnable Project

## Setup
1. Create a Supabase project and run the SQL in `prisma-schema.sql` and `seed.sql` in the SQL editor.
2. Create `.env.local` with the following entries:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

3. Install and run:
```bash
npm install
npm run dev
```

4. Open http://localhost:3000
