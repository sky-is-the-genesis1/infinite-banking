'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';
import { useRouter } from 'next/navigation';

export default function Navbar() {
  const [user, setUser] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    let mounted = true;
    async function getUser() {
      const { data } = await supabase.auth.getUser();
      if (!mounted) return;
      setUser(data.user);
    }
    getUser();
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
    });
    return () => {
      mounted = false;
      try { listener?.subscription?.unsubscribe(); } catch (e) {}
    };
  }, []);

  async function signOut() {
    await supabase.auth.signOut();
    router.push('/auth/login');
  }

  return (
    <nav className="bg-white shadow p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-xl font-bold"><Link href="/">SupaBank</Link></div>
        <div className="flex items-center gap-4">
          <Link href="/dashboard">Dashboard</Link>
          <Link href="/admin">Admin</Link>
          {user ? (
            <>
              <span className="text-sm">{user.email}</span>
              <button onClick={signOut} className="bg-red-500 text-white px-3 py-1 rounded">Sign out</button>
            </>
          ) : (
            <>
              <Link href="/auth/login" className="px-3 py-1 border rounded">Login</Link>
              <Link href="/auth/signup" className="px-3 py-1 bg-blue-600 text-white rounded">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
