-- Replace these ids with actual auth.user uuids from your Supabase Auth table
insert into profiles (id, full_name, role) values
('00000000-0000-0000-0000-000000000001', 'Demo Customer A', 'customer'),
('00000000-0000-0000-0000-000000000002', 'Demo Customer B', 'customer'),
('00000000-0000-0000-0000-000000000003', 'System Admin', 'admin');

insert into accounts (id, user_id, balance) values
(gen_random_uuid(), '00000000-0000-0000-0000-000000000001', 10000.00),
(gen_random_uuid(), '00000000-0000-0000-0000-000000000002', 5000.00);
