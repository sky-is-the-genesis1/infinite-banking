-- Enable pgcrypto for gen_random_uuid (if not already enabled)
create extension if not exists pgcrypto;

-- Profiles table (linked to auth.users)
create table if not exists profiles (
  id uuid references auth.users on delete cascade,
  full_name text,
  role text not null default 'customer',
  created_at timestamptz default now(),
  primary key (id)
);

-- Accounts table
create table if not exists accounts (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade,
  currency text not null default 'KES',
  balance numeric(18,2) not null default 0,
  created_at timestamptz default now()
);

-- Transactions table
create table if not exists transactions (
  id uuid default gen_random_uuid() primary key,
  account_from uuid references accounts(id) on delete set null,
  account_to uuid references accounts(id) on delete set null,
  amount numeric(18,2) not null,
  type text not null, -- 'transfer', 'deposit', 'withdrawal'
  status text not null default 'completed', -- 'pending', 'failed'
  metadata jsonb,
  created_at timestamptz default now()
);

create index if not exists transactions_created_at_idx on transactions (created_at desc);
create index if not exists accounts_user_id_idx on accounts (user_id);

-- Atomic transfer function (uses FOR UPDATE locking and a lightweight advisory lock)
create or replace function transfer_atomic(p_from uuid, p_to uuid, p_amount numeric) returns table(success boolean, message text) as $$
declare
  from_balance numeric;
begin
  perform pg_advisory_xact_lock(1);

  select balance into from_balance from accounts where id = p_from for update;
  if from_balance is null then
    return query select false, 'From account not found';
  end if;
  if from_balance < p_amount then
    return query select false, 'Insufficient funds';
  end if;

  update accounts set balance = balance - p_amount where id = p_from;
  update accounts set balance = balance + p_amount where id = p_to;

  insert into transactions(account_from, account_to, amount, type, status) values (p_from, p_to, p_amount, 'transfer', 'completed');

  return query select true, 'OK';
end;
$$ language plpgsql;

-- Enable Row Level Security (RLS) and create policies

-- Profiles policies
alter table profiles enable row level security;
create policy profiles_insert_own on profiles for insert with check (id = auth.uid());
create policy profiles_select_own_or_admin on profiles for select using (id = auth.uid() or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));
create policy profiles_update_own on profiles for update using (id = auth.uid());

-- Accounts policies
alter table accounts enable row level security;
create policy accounts_select_owner on accounts for select using (user_id = auth.uid() or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));
create policy accounts_insert_owner on accounts for insert with check (user_id = auth.uid());
create policy accounts_update_owner on accounts for update using (user_id = auth.uid());
create policy accounts_delete_owner on accounts for delete using (user_id = auth.uid());

-- Transactions policies
alter table transactions enable row level security;
create policy transactions_select_owner on transactions for select using (
  exists (select 1 from accounts a where a.id = account_from and a.user_id = auth.uid())
  or exists (select 1 from accounts a where a.id = account_to and a.user_id = auth.uid())
  or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy transactions_insert_owner on transactions for insert with check (
  auth.role() = 'service_role' or
  exists (select 1 from accounts a where a.id = account_from and a.user_id = auth.uid())
);

-- Note: service_role (SUPABASE_SERVICE_ROLE_KEY) bypasses RLS and should be used only server-side.
